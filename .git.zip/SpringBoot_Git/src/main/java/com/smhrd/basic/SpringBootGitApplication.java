package com.smhrd.basic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGitApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGitApplication.class, args);
	}

}
