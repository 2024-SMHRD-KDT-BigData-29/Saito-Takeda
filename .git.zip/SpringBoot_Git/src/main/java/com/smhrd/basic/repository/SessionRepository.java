package com.smhrd.basic.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

<<<<<<< HEAD
import com.smhrd.basic.model.Session;
=======
import com.smhrd.basic.entity.Session;
>>>>>>> branch 'master' of https://github.com/2024-SMHRD-KDT-BigData-29/Saito-Takeda.git

<<<<<<< HEAD
=======
@Repository
>>>>>>> branch 'master' of https://github.com/2024-SMHRD-KDT-BigData-29/Saito-Takeda.git
public interface SessionRepository extends JpaRepository<Session, Long>{

}
