package com.smhrd.basic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.smhrd.basic.repository.BoardRepositroy;

@Controller
public class BoardController {
	// 게시판 컨트롤러ㅓㅓㅓㅓㅓㅓㅓㅓㅓㅓ
	
	@Autowired
	BoardRepositroy repository;
	
}
