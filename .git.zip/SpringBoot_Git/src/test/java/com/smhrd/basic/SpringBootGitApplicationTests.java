package com.smhrd.basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootGitApplicationTests {

	@Test
	void contextLoads() {
	}

}
